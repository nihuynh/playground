# Alfred Workflow : Firefox to Helium


This script or alfred workflow will grab the front tab of firefox and open it in Helium.    
This will also close the tab on firefox.

![Example Image](https://github.com/Cakeofruit/Alfred-Workflows/blob/master/Exemple_F2H.png)

![Example Gif](https://github.com/Cakeofruit/Alfred-Workflows/blob/master/Alfred_port.gif)


## Getting Started

Open the worflow with Alfred  -or-  download the file Export2Firefox.scpt.

### Prerequisities

	Require ==> Mac OSX Yosemite or ++ <==

Tested on ElCapitain

## Versioning

V0.1

## Authors

* **Nicolas Huynh**  - [Cakeofruit](https://github.com/Cakeofruit)

## Acknowledgments
[jeremyemiller.com](jeremyemiller.com)  (for the JXA first step)
*
