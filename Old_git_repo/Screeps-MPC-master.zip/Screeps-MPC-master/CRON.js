// var sark = require('SARK');
var yori = require('YORI');
var ram = require('RAM');
var clu = require('CLU');
var io = require('IO');

var CRON;
CRON = {
    // Setters :
    // Getters :
    // scan, Index, make screen shot of the situation
    clearMemory : function () {
        for (let name in Memory.creeps) {
            if (Game.creeps[name] == undefined) {
                delete Memory.creeps[name];
            }
        }
    },
    checkWorkers : function (maxWorkers) {
        if (ram.countDrone() < maxWorkers && Game.creeps.length == undefined && Game.spawns['main'].room.energyAvailable > 200) {
            clu.spawnDrone(['CUSTOMWORKER']);
        }
    },
    scanWorkers : function (isIO) {
        var carryOption = ['Full', 'Mid-Load','Empty'];
        for (var idCarry in carryOption){
            var type = carryOption[idCarry]
            if (isIO) {
                console.log('Checking on the' + type + ' drone : ');
            }
            var droneList = ram.findBaseCarryLoad(type);
            for (var id in droneList) {
                var drone = droneList[id];
                if (drone.memory.carryLoad != type) drone.memory.carryLoad = type;
                yori.updateTask(drone);
                yori.operate(drone);
                if (isIO) {
                    io.droneReview(drone);
                }
            }
        }
    }


};

module.exports = CRON;