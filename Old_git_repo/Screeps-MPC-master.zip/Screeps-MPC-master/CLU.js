var CLU;
CLU = {
    // Setters :

    // All the helper functions :
    setTask : function (drone, task) {
        drone.memory.task = task;
        drone.say(task);
    },
    // Getters :

    // Spawn a worker :
    spawnDrone : function (parts) {
        //MAKE DYNAMIC WORKER PART
        if(parts[0] == 'CUSTOMWORKER'){
            var totalEnergyCapacity = Game.spawns['main'].room.energyCapacityAvailable;
            var numberOfPart = Math.floor(totalEnergyCapacity /200);
            console.log("Spawning a program level : " + numberOfPart);
            parts = [];
            for(let i = 0; i < numberOfPart; i++){
                parts.push(WORK);
            }
            for(let i = 0; i < numberOfPart; i++){
                parts.push(CARRY);
            }
            for(let i = 0; i < numberOfPart; i++){
                parts.push(MOVE);
            }
        }
        Game.spawns['main'].createCreep(parts, undefined, {task : 'Harvest', carryLoad : 'Empty', level : Math.floor(parts.length/3)});
    }

        //  TRASH
    // iterateDrone : function (droneList) {
    //     for (var name in droneList) {
    //         // do stuff
    //     }
    // }
};
module.exports = CLU;