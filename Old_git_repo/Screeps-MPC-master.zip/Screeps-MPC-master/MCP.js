//var clu = require('CLU'); // All the helper functions
var cron = require('CRON'); // scan, Index, make screen shot of the situation
var ram = require('RAM'); // store data, recover data
// var sark = require('SARK'); // Task manager
// var yori = require('YORI'); // Creep AI
var io = require('IO');
var MCP;
MCP = {
    compute : function () {
        cron.clearMemory();
        io.review();

    },
    decide: function () {
        // Structures manager
        // Drone manager
        // Warrior manager
        cron.checkWorkers(10);
        cron.scanWorkers(true);
    },
    bilan : function () {
        // io.review();
        io.endCycle();
    }
};

module.exports = MCP;