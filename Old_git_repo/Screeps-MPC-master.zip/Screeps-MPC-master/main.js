/*
 * Learn js with screeps
 * Create by Nicolas Huynh
 * 14/09/2016
 */
var mcp = require('MCP');
module.exports.loop = function () {
    mcp.compute();
    mcp.decide();
    mcp.bilan();
};