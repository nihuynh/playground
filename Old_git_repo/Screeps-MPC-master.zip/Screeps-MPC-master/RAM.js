var RAM;
RAM = {
    // Getters :
        // storage :
    storageSpot : function(drone) {
        var energyStructure = drone.pos.findClosestByPath(FIND_MY_STRUCTURES,
            {filter: (s) => s.energy < s.energyCapacity});
        if(energyStructure != undefined) {
            return energyStructure;
        }
        return 0;
    },

    storageCapacity  : function(){
        return Game.spawns['main'].room.energyCapacityAvailable;
    },

    isStorageFull : function () {
        return (Game.spawns['main'].room.energyCapacityAvailable == Game.spawns['main'].room.energyAvailable)
    },

        // Building :
    builtSpot : function(drone){
        return Game.spawns['main'].pos.findClosestByPath(FIND_MY_CONSTRUCTION_SITES);
    },

    countBuiltSpot : function () {
        return Game.spawns['main'].room.find(FIND_MY_CONSTRUCTION_SITES).length;
    },

        // Repair :
    repairSpot : function(drone) {
        var res = drone.pos.findClosestByPath(FIND_MY_STRUCTURES,
            {filter: (s) => s.hits < s.hitsMax && s.structureType != STRUCTURE_WALL});
        if(res != undefined) {
            return res
        }
        return 0
    },

    countRepairSpot : function () {
        return _.sum(Game.structures, (s) => s.hits < s.hitsMax && s.structureType != STRUCTURE_WALL);
    },

    // Lists :
    countDrone  : function(){
        return Game.spawns['main'].room.find(FIND_MY_CREEPS).length;
    },

    findWorker : function (task) {
        return Game.spawns['main'].room.find(FIND_MY_CREEPS, {
            filter:(c) => c.memory.task == task});
    },

    findBaseCarryLoad : function (wantedCarryLoad) {
        switch (wantedCarryLoad) {
            case 'Full' :
                var targets = Game.spawns['main'].room.find(FIND_MY_CREEPS, {filter:(c) => c.carry.energy == c.carryCapacity});
                break;
            case 'Empty' :
                var targets = Game.spawns['main'].room.find(FIND_MY_CREEPS, {filter:(c) => c.carry.energy == 0});
            break;
        case 'Mid-Load' :
            var targets = Game.spawns['main'].room.find(FIND_MY_CREEPS, {filter:(c) => c.carry.energy != (c.carryCapacity && c.carry.energy != 0)});
            break;
        }
        if(targets != undefined) {
            return targets;
        }
        return 0;
    },

    countWorker  : function(task){
        return _.sum(Game.creeps, (c) => c.memory.task == task)
    },

    // store data, recover data
    miningSpot : function(drone){
        var res;
        res = drone.pos.findClosestByPath(FIND_SOURCES,
            {filter: (s) => s.energy != 0,
            });
        return [res]
    },

    spawnSpot : function(drone){
        return drone.pos.findClosestByPath(FIND_MY_SPAWNS);
    }
};


module.exports = RAM;