// var clu = require('CLU'); // All the helper functions
// var cron = require('CRON'); // scan, Index, make screen shot of the situation
var ram = require('RAM'); // store data, recover data
// var sark = require('SARK'); // Task manager
// var yori = require('YORI'); // Creep AI


var IO;
IO = {
    review: function () {
        // Structure review
        var energyReview = '    Energy storage : ' + parseFloat(Game.spawns['main'].room.energyAvailable/Game.spawns['main'].room.energyCapacityAvailable).toFixed(2) +
            '   Storage : ' + Game.spawns['main'].room.energyAvailable + ' / ' + Game.spawns['main'].room.energyCapacityAvailable;
        var buildingReview =  '    Constructions sites : ' + ram.countBuiltSpot() + '   Repair sites : ' + ram.countRepairSpot() + '    Room Level : ';
        console.log(
            energyReview +
            buildingReview
        );
        // Drone review
        console.log(
            ' Idle : ' + ram.countWorker('Idle') +
            '   IdleFull : ' + ram.countWorker('IdleFull') +
            '   Harvest : ' + ram.countWorker('Harvest') +
            '   Drop : ' + ram.countWorker('Drop')  +
            '   Upgrade : ' + ram.countWorker('Upgrade') +
            '   Built : ' + ram.countWorker('Built') +
            '   Repair : ' + ram.countWorker('Repair') +
            '   Total : ' + ram.countDrone()
        );



        // Worker
        // Harvest
        // Carry
        // Upgrade
        // Repair
        // Warrior review
    },
    droneReview  : function (drone) {
        var energyReview = parseFloat(drone.carry.energy/drone.carryCapacity).toFixed(2) + ' : ' + drone.carry.energy + ' / ' + drone.carryCapacity;
        var internalMem =  drone.memory.task + ' | ' + drone.memory.carryLoad + ' | ' + drone.name;
        console.log(
            '   Energy : ' + energyReview +
            '   Internal memory : ' + internalMem
        );
    },
    endCycle : function () {
        var linePass = (Math.floor(ram.countDrone()/5) + 1) * 5 - ram.countDrone();
        for (var i = linePass; i > 0 ; i --){
            console.log();
        }
    }
};

module.exports = IO;