var clu = require('CLU');
var ram = require('RAM');
var YORI;
YORI = {
    /** @param {Creep} drone **/
    updateTask : function(drone) {
        function droneChoice() {
            if (!ram.isStorageFull()) {
                clu.setTask(drone, 'Drop');
                if (ram.countWorker('Upgrade') < 1 / 4) {
                    clu.setTask(drone, 'Upgrade');
                }
            } else if (ram.countBuiltSpot() > 0) {
                clu.setTask(drone, 'Built');
            } else if (ram.countRepairSpot(drone) > 0) {
                clu.setTask(drone, 'Repair');
            } else {
                clu.setTask(drone, 'Upgrade');
                console.log(ram.countBuiltSpot() < 1);
                console.log(ram.countRepairSpot() < 1);
            }
            console.log('program' + drone.name + 'has choice => ' + drone.memory.task);
        }

        // if (ram.storageSpot(drone) == undefined && drone.memory.task == 'Drop') clu.setTask(drone, 'Idle');
        // if (ram.repairSpot(drone) == undefined && drone.memory.task == 'Repair') clu.setTask(drone, 'Idle');
        // if (ram.builtSpot(drone) == undefined && drone.memory.task == 'Built') clu.setTask(drone, 'Idle');
        switch (drone.memory.carryLoad) {
            case 'Full':
                if (drone.memory.task == 'Harvest' || drone.memory.task == 'Idle') clu.setTask(drone, 'IdleFull');
                break;
            case 'Empty':
                clu.setTask(drone, 'Harvest');
                break;
            case 'Mid-Load':
                if (drone.memory.task == 'IdleFull') clu.setTask(drone, 'Idle');
                break;
            default:
                console.log('ERROR :  ' + load + ' is not a valid load.');
        }
        // Operate all the idle drones :
        if (drone.memory.task === 'IdleFull') droneChoice(drone); else if (drone.memory.task === 'Idle') droneChoice(drone);
    },
    /** @param {Creep} drone **/
    operate : function (drone){
        // Function operation :
        function harvest(){
            if(drone.harvest(ram.miningSpot(drone)[0]) == ERR_NOT_IN_RANGE) {
                drone.moveTo(ram.miningSpot(drone)[0]);}
        }

        function repair(){
            if (ram.repairSpot(drone) != undefined ) {
                if (drone.repair(ram.repairSpot(drone)) == ERR_NOT_IN_RANGE) {
                    drone.moveTo(ram.repairSpot(drone));
                }
            }
            if (ram.countRepairSpot(drone) < 1){
                clu.setTask(drone,'Upgrade');
                console.log('changing task during repair');
            }
        }

        function upgrade(){
            if (drone.upgradeController(drone.room.controller) == ERR_NOT_IN_RANGE) {
                drone.moveTo(drone.room.controller);
            } else {clu.setTask(drone, 'Idle');}
        }

        function built(){
            if (ram.builtSpot(drone) != undefined ) {
                if (drone.build(ram.builtSpot(drone)) == ERR_NOT_IN_RANGE) {
                    drone.moveTo(ram.builtSpot(drone));
                }
            } else {clu.setTask(drone, 'Idle');}
        }

        function drop() {
            if(ram.storageSpot(drone) != 0) {
                if (drone.transfer(ram.storageSpot(drone), RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    drone.moveTo(ram.storageSpot(drone));
                }
            }
            if (ram.isStorageFull()) clu.setTask(drone, 'Idle');
        }


        // Operate the drone :
        switch(drone.memory.task) {
            case 'Harvest':
                harvest();
                break;
            case 'Repair':
                repair();
                break;
            case 'Upgrade':
                upgrade();
                break;
            case 'Built':
                built();
                break;
            case 'Drop':
                drop();
                break;
            default: console.log('ERROR :  ' + drone.memory.task + ' is not a valid task.');
        }
    }
};
module.exports = YORI;