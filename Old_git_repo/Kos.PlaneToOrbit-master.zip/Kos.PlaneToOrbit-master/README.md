# Kos.PlaneToOrbit    
===================    

This git contain 2 SSTO and a program to fly them and a program for a space shuttle with the craft files.    
WARNING : The scripts need a 20k drive to load all the lib and script.    

## How to use boot
To boot the command is ``run boot(typeMission, boolConfig).``    
For exemple for ssto it's : ``run boot(ssto, true).``


## Mods use for the craft    
+ [Adjustable Landing Gear](https://kerbalstuff.com/mod/321/Adjustable%20Landing%20Gear)    
And of course :    
+ [kOS](https://kerbalstuff.com/mod/86/kOS:%20Scriptable%20Autopilot%20System)    

### prg_ssto :    
It's almost sure to work with the two craft on this git and maybe other (give me feed-back).    

### prg_shuttle :    
We went to orbit :)    

## News Feed :    
22/10 : We reach space !    
22/10 : We have our first orbit 112 000 * 70 000    
04/11 : The shuttle program have worked once to bring the shuttle to space(sub-orbital).    

## To Do :    
The 18.2 update (check run, version checking)    
Bash for removing the comment    
Manuvernode boot 
Ui : Move the list to queue http://ksp-kos.github.io/KOS_DOC/structures/misc/queue.html    
SSTO :    
======
+ Better circularization burn

Shuttle :
=========    
AG 5 for the solar panel    

+ Thrust limit to reduce the torque created during the flight      
+ Thrust limit to avoid overheat    

## Formatting :    
camelCase for all the variable.
ALL-CAPS for functions, commands and global variable declarations like BRAKES and RCS.    
Runmode Value   
============= 
-10 init    
-9 countdown    
-1 End the Loop    
0 First runmode    
99 => only print data AG to break or abort    

# credits :    
Thanks to **StrawberryMeringue** for the advice (the formatting guideline and more !) and get the boot script 3 times smaller !    

# Ressoures :    
https://bitbucket.org/andrey_zakharov_/autopilot (Didin't use very much, it's a amazing git !).    
https://github.com/gisikw/ksprogramming (Thx for this awesome serie !).    
https://github.com/xeger/kos-ramp (Get git with a lot of stuff, i grab the prep boot for my boot script).    
https://github.com/akrasuski1/akrOS (Well i love ui and this one look very nice !).    
