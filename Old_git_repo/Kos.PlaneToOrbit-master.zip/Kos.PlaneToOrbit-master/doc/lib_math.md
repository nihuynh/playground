## lib_math

``lib_math.ks`` is a bunch of operations and getters.

### IS_BETWEEN

args:
  * a value to check.
  * a min value and a max value.

returns:
  * True or false depending on whether the value is between the minvalue and the maxValue.

### LN_N

args:
  * a value.
  * a base 'n' for the log

returns:
  * the log_n(value).

### DISK_USAGE

returns:
  * The usage of the disk
  0 : the disk is empty,
  100 : the disk is full.

### REAL_THRUST

returns:
  * total thrust of all the engines.

### MAXTHRUSTSEEN

returns:
  * the max REAL_THRUST found during the flight.

### TWR

returns:
  * trust weight ratio.

### MAXTHRUSTSEEN

returns:
  * the max REAL_THRUST found during the flight.

### DELTAPITCH

args:
  * a vector.

returns:
  * delta pitch between the vector and the prograde vector of the ship.


### AOA

returns:
  * angle of attack of the ship.
