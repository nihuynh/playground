// This file is distributed under the terms of the MIT license, (c) the KSLib team

## lib_beep

A small "hack" to insert quote character and next line character into strings.
**important:**
  * This library is a .ksm file and is placed in the library_ksm folder.
  * This solution is temporary. A way to get these symbols in kerboscript
    will be introduced soon.
  * Because it is .ksm file it might stop working in some future versions of kOS.

### quote

A global variable set to a value of one quote.

### endl

A global variable set to a line feed symbol.

### beep

A global variable that sounds a beep in the ingame and any connected telnet terminals.
