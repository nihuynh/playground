## lib_boot.

``lib_boot.ks`` provides useful routines for the file manipulation.

### HASFILE

args:
  * a file name.
  * a volume to check.

returns:
  * True or false depending on whether the file in question is on the current volume.

description:
  * Returns the true if the file is in the volume.

### DOWNLOAD

args:
  * a file name.

returns:
  * nothing.

description:
  * Copy the file from the archive to the disk 1.

### UPLOAD

args:
  * a file name.

returns:
  * the name of the file upload.

description:
  * Copy the file to the archive.

### INIT_FILE

args:
  * a file name.

returns:
  * nothing.

description:
  * Purge the file, it delete it on 1 and the archive.

### EXEC_WT_LIB

args:
  * a program name.
  * a boolean.

returns:
  * nothing.

description:
  * This launch a prg_'arg1' and if the bool is true it also load config_'arg1' or config_'ship:name'.