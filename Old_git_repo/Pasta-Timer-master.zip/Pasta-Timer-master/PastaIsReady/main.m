//
//  main.m
//  PastaIsReady
//
//  Created by Nico on 04/02/2015.
//  Copyright (c) 2015 Nico. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppleScriptObjC/AppleScriptObjC.h>

int main(int argc, const char * argv[]) {
    [[NSBundle mainBundle] loadAppleScriptObjectiveCScripts];
    return NSApplicationMain(argc, argv);
}
